import pandas as pd

# Membuat DataFrame kosong
df = pd.DataFrame(columns=['ips-now'])

# Menampilkan DataFrame kosong
print(df)